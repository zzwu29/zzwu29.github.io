import numpy as np
import os

import re

# import sys
# sys.path.append(r"D:/github_project/frame-interpolation")

step = 1
data = np.loadtxt("image_intp_step_"+str(step)+".txt",dtype=str)
# print(data)

dir = os.getcwd()

# python -m eval.interpolator_test  --frame1 D:\datasets\20230414_GIUVL\img0\data\img_proc\465888200000000.jpg --frame2 D:\datasets\20230414_GIUVL\img0\data\img_proc\465888400000000.jpg --model_path D:/github_project/film_net_model/film_net/Style/saved_model --output_frame D:\datasets\20230414_GIUVL\img0\data\img_proc\465888300000000.jpg

os.chdir("D:/github_project/frame-interpolation")

idx = 0
for img in data[:,0]:
    value = re.split("/|\\\\",img)
    
    run_cmd = "python -m eval.interpolator_test " + \
        " --frame1 " + data[idx,1] + " " +\
        " --frame2 " + data[idx,2] + " " +\
        " --model_path D:/github_project/film_net_model/film_net/Style/saved_model " +\
        " --output_frame " + dir + "/" + value[-1]
    # print(run_cmd)
    os.system(run_cmd)

    idx = idx + 1

print("----- recover step "+str(step)+" ok! -----")