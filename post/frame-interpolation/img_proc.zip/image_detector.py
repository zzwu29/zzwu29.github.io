from PIL import Image
import os

# 功能：查看图片能否打开，有没有这个图片、是不是完好、没有损坏的图片
# 参数：图片路径
# 返回：True
def check_pic(path_pic):
    try:
        img = Image.open(path_pic)    # 如果图片不存在，报错FileNotFoundError
        img.load()    # 如果图片不完整，报错OSError: image file is truncated
        return 0
    except FileNotFoundError:
        return 1
    except OSError:
        return 2

if __name__ == '__main__':
    paths = os.walk(r"D:/datasets/20230414_GIUVL/img0/data")

    idx = 0

    img_valid = []
    img_names = []

    step = 1

    print("---------- image detect step "+str(step)+" start -----------")
    with open("image_log_step_"+str(step)+".txt", 'w') as f_log:
        for path, dir_lst, file_lst in paths:
            for file_name in file_lst:
                if file_name[-3:] != "jpg":
                    continue
                path_pic = os.path.join(path, file_name)

                # print(os.path.join(path, file_name))
                status = check_pic(path_pic)
                if status == 1:
                    print("Lost file : " + file_name, file = f_log)
                if status == 2:
                    print("Wrong file : " + file_name, file = f_log)
                
                img_names.append(path_pic)
                img_valid.append(status)
                idx = idx + 1
    print("---------- image detect step "+str(step)+" end -----------")

    print("---------- image identify step "+str(step)+" start -----------")
    with open("image_intp_step_"+str(step)+".txt", 'w') as f_itp, open("image_err_step_"+str(step)+".txt", 'w') as f_err:
        for i in range(len(img_valid)):
            if img_valid[i] == 0:
                continue
            
            # 超过索引无法内插
            if i - step < 0 or i + step > len(img_valid) - 1:
                msg = img_names[i]+"\t"+"error"+"\t"+"error"
                print(msg, file = f_err)
                continue

            if img_valid[i - step] != 0 or img_valid[i + step] != 0:
                msg = img_names[i]+"\t"+"error"+"\t"+"error"
                print(msg, file = f_err)
                continue
            
            msg = img_names[i]+"\t"+img_names[i-step]+"\t"+img_names[i+step]
            print(msg, file = f_itp)
    print("---------- image identify step "+str(step)+" end -----------")
