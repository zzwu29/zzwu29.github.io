import numpy as np
import matplotlib.pyplot as plt
import re

import scienceplots
plt.style.use(['science','nature'])


data = np.loadtxt("step_1/image_err_step_1.txt",dtype=str)

timestamp=[]
for value in data[:,0]:
    segs = re.split("/|\\\\",value)
    timestamp.append(float(segs[-1][0:-4])/1e9)

timestamp=np.array(timestamp)
dt = timestamp[1:]-timestamp[0:-1]

# plt.style.use('q13')
# print(plt.style.available)
fig, ax = plt.subplots()
ax.plot(dt)
plt.show()
# fig.tight_layout()
# plt.savefig("step1_err.png",dpi=300)


